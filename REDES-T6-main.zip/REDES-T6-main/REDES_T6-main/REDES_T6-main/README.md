# REDES_T6
Padrões Ethernet

Atividade:

A partir do protótipo Front-end da pasta PEthernet completar javascript para que a aplicação selecione todos os padrões possíveis a partir dos dados: 

Distância Máxima:

Tipo de Conector:

Ao final subir a aplicação para o Github Pages e indicar o caminho via preenchimento no formulário abaixo:

https://almeida-cma.github.io/receber/
