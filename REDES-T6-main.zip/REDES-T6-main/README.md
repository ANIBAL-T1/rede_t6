# REDES-T6
Seletor de Padrões de Cabos Ethernet
